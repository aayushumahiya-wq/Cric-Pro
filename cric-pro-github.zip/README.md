# Cric-Pro (CrickBox Pro)

Turf & Corporate Cricket Tournament Manager web application.

## Features
- Manage teams & rosters
- Automated round-robin fixture generator
- Live points table with Net Run Rate (NRR) calculation
- Razorpay ₹999 Pro Pass integration
- Supabase cloud sync support
